function startPrank() {
    let button = document.getElementById("loginButton");
    let container = document.querySelector(".container");

    // Запускаем тряску контейнера
    container.classList.add("shaking");
    setTimeout(() => {
        container.classList.remove("shaking");
    }, 1000);

    // Делаем кнопку "убегающей"
    button.style.position = "absolute";
    button.style.left = Math.random() * (window.innerWidth - 100) + "px";
    button.style.top = Math.random() * (window.innerHeight - 50) + "px";
}
